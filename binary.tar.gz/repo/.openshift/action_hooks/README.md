For information about which action hooks are supported, consult the OpenShift documentation:

https://github.com/openshift/origin-server/blob/master/node/README.writing_applications.md
